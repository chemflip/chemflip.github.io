# ChemFlip Microsoft Store helper. Usage: store.ps1 <status|products|buy> [plan] [hwnd]
param([string]$cmd = "status", [string]$plan = "", [string]$hwnd = "0")
$ErrorActionPreference = "Stop"
function Out-Json($o) { [Console]::Out.Write(($o | ConvertTo-Json -Compress -Depth 5)) }
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices;
[ComImport, Guid("3E68D4BD-7135-4D10-8018-9FB6D9F33FA1"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IInitializeWithWindow { void Initialize(IntPtr hwnd); }
public static class CfWin { public static void Init(object o, long h) { ((IInitializeWithWindow)o).Initialize(new IntPtr(h)); } }
"@
  $asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq "AsTask" -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
  function Await($op, [Type]$t) { $task = $asTask.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result }
  [Windows.Services.Store.StoreContext, Windows.Services, ContentType = WindowsRuntime] | Out-Null
  $ctx = [Windows.Services.Store.StoreContext]::GetDefault()
  if ([long]$hwnd -ne 0) { [CfWin]::Init($ctx, [long]$hwnd) }
  function Get-Products {
    $kinds = [System.Collections.Generic.List[string]]::new(); $kinds.Add("Durable")
    $r = Await ($ctx.GetAssociatedStoreProductsAsync($kinds)) ([Windows.Services.Store.StoreProductQueryResult])
    if ($r.ExtendedError) { throw "Store error $($r.ExtendedError.HResult)" }
    $list = @(); foreach ($kv in $r.Products) { $list += $kv.Value }; return $list
  }
  switch ($cmd) {
    "status" {
      $lic = Await ($ctx.GetAppLicenseAsync()) ([Windows.Services.Store.StoreAppLicense])
      $active = $false; $which = @()
      foreach ($kv in $lic.AddOnLicenses) { if ($kv.Value.IsActive) { $active = $true; $which += $kv.Value.InAppOfferToken } }
      Out-Json @{ ok = $true; active = $active; addons = $which }
    }
    "products" {
      $ps = Get-Products; $by = @{}
      foreach ($x in $ps) { if ($x.InAppOfferToken) { $by[$x.InAppOfferToken] = $x.Price.FormattedPrice } }
      Out-Json @{ ok = $true; count = $ps.Count; byId = $by }
    }
    "buy" {
      $ps = Get-Products; $p = $ps | Where-Object { $_.InAppOfferToken -eq $plan } | Select-Object -First 1
      if (-not $p) { Out-Json @{ ok = $false; status = "Missing"; error = "This plan isn't available in the Store yet." }; break }
      $res = Await ($ctx.RequestPurchaseAsync($p.StoreId)) ([Windows.Services.Store.StorePurchaseResult])
      Out-Json @{ ok = $true; status = "$($res.Status)"; error = $(if ($res.ExtendedError) { "Store error $($res.ExtendedError.HResult)" } else { $null }) }
    }
  }
} catch { Out-Json @{ ok = $false; status = "Error"; error = "$($_.Exception.Message)" } }
